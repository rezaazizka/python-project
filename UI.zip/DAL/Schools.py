import json

class School:
    
    def __init__(self,Name,Location):
        self.Name = Name
        self.Location = Location
        



class Schools:

    #TODO باید آیدی ها خود به خود اضافه شوند و دست کاربر نباشند
    #اضافه کردن مدرسه

    @staticmethod
    def Add(school:School):
        with open("DAL/Jsons/Id/School", "r") as f:
            Id = f.read()
        MId = int(Id) + 1        
        school_data = {
            "Id":MId,
            "Name":school.Name,
            "Location":school.Location,
        }
        
        with open("DAL/Jsons/Id/School", "w") as f:
            f.write(str(MId))
        
        data = Schools.loadData()
        data[MId] = school_data
        Schools.saveData(data)
        
    #حذف کردن یک مدرسه
    @staticmethod
    def Remove(Id:int):
        data = Schools.loadData()
        del data[str(Id)]
        Schools.saveData(data)
    
    #لیست تمام مدارس    
    @staticmethod
    def schoolsNameList():
        data = Schools.loadData()
        result = []
        for i in data:
            result.append(data[i]["Name"])
        return result
    
    #دیتای تمام مدارس
    @staticmethod
    def allSchools():
        data = Schools.loadData()
        result = []
        for i in data:
            result.append(data[i])
        return result          
        
    #پیداکردن یک مدرسه با استفاده از آیدی
    @staticmethod
    def findById(Id):
        data = Schools.loadData()
        return data[str(Id)]

    @staticmethod
    def Edit(Id, newschool:School):
        data = Schools.loadData()
        
        data[str(Id)] = {
            "Id":Id,
            "Name":newschool.Name,
            "Location":newschool.Location,
        }
        
        
        Schools.saveData(data)
        


    # گرفتن دیتا از دیسک
    @staticmethod
    def loadData():
        data = {}
        with open("DAL/Jsons/Schools.json", "r") as f:
            data = json.loads(f.read())
        return data
        f.close()    

    # سیو کردن دیتا در دیسک
    @staticmethod
    def saveData(data):
        with open("DAL/Jsons/Schools.json", "w") as f:
            json.dump(data,f)
        f.close()    




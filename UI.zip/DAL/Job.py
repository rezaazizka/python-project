import json

class Job:
    
    def __init__(self,Title):
        self.Title = Title
        



class Jobs:

    #TODO باید آیدی ها خود به خود اضافه شوند و دست کاربر نباشند
    @staticmethod
    def Add(job:Job):
        
        with open("DAL/Jsons/Id/Job", "r") as f:
            Id = f.read()
        MId = int(Id) + 1
        
        job_data = {
            "Id":MId,
            "Title":job.Title,
        }
        
        with open("DAL/Jsons/Id/Job", "w") as f:
            f.write(str(MId))
        
        data = Jobs.loadData()
        data[MId] = job_data
        Jobs.saveData(data)
    
        
    @staticmethod
    def Remove(Id:int):
        data = Jobs.loadData()
        del data[str(Id)]
        Jobs.saveData(data)
        
        
    
    
    
        
    

    @staticmethod
    def findIdBy(jobTitle):
        data = Jobs.loadData()
        for i in data:
            if data[i]["Title"] == jobTitle:
                return data[i]
        #TODO ارور نبود تیپ


    @staticmethod
    def Edit(Id, newjob:Job):
        data = Jobs.loadData()
        
        data[str(Id)] = {
            "Id":Id,
            "Title":newjob.Title,
        }
        
        
        Jobs.saveData(data)

    @staticmethod
    def loadData():
        data = {}
        with open("DAL/Jsons/Jobs.json", "r") as f:
            data = json.loads(f.read())
        f.close()    
        return data

    @staticmethod
    def saveData(data):
        with open("DAL/Jsons/Jobs.json", "w") as f:
            json.dump(data,f)
        f.close()    




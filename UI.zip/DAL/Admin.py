import json

#یوزری است که توانایی های بالایی برای مثال یوزر روت که تنها اوست که می تواند ادمین اضافه کند
class Admin:
    
    def __init__(self,UserId,AdminTypeId):
        self.UserId = UserId                    #از این طریق به یوزر خود وصل است
        self.AdminTypeId = AdminTypeId          #ادمین های مختلفی وجود دارد که دسترسی های متفاوتی دارند
        


#ادمین ها را با این کلاس مدیریت می کنیم
class Admins:

    
    #اضافه کردن ادمین جدید که یک ادمین به عنوان ورودی می گیرد
    @staticmethod
    def Add(admin:Admin):
        with open("DAL/Jsons/Id/Admin", "r") as f:
            Id = f.read()
        MId = int(Id) + 1
        admin_data = {
            "Id":MId,
            "UserId":admin.UserId,
            "AdminTypeId":admin.AdminTypeId
        }
        with open("DAL/Jsons/Id/Admin", "w") as f:
            f.write(str(MId))
        
        data = Admins.loadData()
        data[MId] = admin_data
        Admins.saveData(data)

    # حذف کردن ادمین (حتما یک ادمین روت وجود داشته باشد)
    # آیدی ادمین را می گیرد و آن را حذف
    @staticmethod
    def Remove(Id:int):
        data = Admins.loadData()
        del data[str(Id)]
        Admins.saveData(data)
        
    #پیدا کردن ادمین با استفاده از آیدی آن        
    @staticmethod
    def findById(Id):
        data = Admins.loadData()
        return data[str(Id)]

    # ادیت ادمین
    #TODO باید در آینده تکمیل شود ... دو ادمین می گیرد و اولی را به دومی تبدیل و ذخیره می کند
    @staticmethod
    def Edit(Id, newadmin:Admin):
        data = Admins.loadData()
        
        data[str(Id)] = {
            "Id":Id,
            "UserId":newadmin.UserId,
            "AdminTypeId":newadmin.AdminTypeId
        }
        
        
        Admins.saveData(data)



    #لود کردن دیتا از هارد
    @staticmethod
    def loadData():
        data = {}
        with open("DAL/Jsons/Admin.json", "r") as f:
            data = json.loads(f.read())
        f.close()    
        return data

    #سیو کردن دیتا در هارد
    @staticmethod
    def saveData(data):
        with open("DAL/Jsons/Admin.json", "w") as f:
            json.dump(data,f)
        f.close()    
                    



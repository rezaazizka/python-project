import json

import BLL.Massage as massage
class Group:
    
    #نکته مهم این است که پیام ها در صورت خالی بودن یک لیست خالی باشد نه none
    def __init__(self,Title,MembersId,AdminId,GroupTypeId,DefaultAgeRange = 0,MassagesId = []):
        self.Title = Title
        self.MembersId = MembersId
        self.AdminId = AdminId
        self.MassagesId = MassagesId
        self.DefaultAgeRange = DefaultAgeRange
        self.GroupTypeId = GroupTypeId
        
        
class Groups:
    
    #TODO باید آیدی ها خود به خود اضافه شوند و دست کاربر نباشند
    #اضافه کردن گروه
    
    @staticmethod
    def Add(group:Group):
        with open("DAL/Jsons/Id/Group", "r") as f:
            Id = f.read()
        MId = int(Id) + 1
        group_data = {
            "Id":MId,
            "Title":group.Title,
            "MembersId":group.MembersId,
            "AdminId":group.AdminId,
            "MassagesId":group.MassagesId,
            "DefaultAgeRange":group.DefaultAgeRange,
            "GroupTypeId":group.GroupTypeId
        }
        
        with open("DAL/Jsons/Id/Group", "w") as f:
            f.write(str(MId))
        
        data = Groups.loadData()
        data[MId] = group_data
        Groups.saveData(data)
        
    
    #اضافه کردن پیام به گروه
    @staticmethod
    def addMassagesId(groupId,massagesId):
        data = Groups.loadData()
        if type(data[str(groupId)]["MassagesId"]) != list:
            data[str(groupId)]["MassagesId"] = list(data[str(groupId)]["MassagesId"])
        
        data[str(groupId)]["MassagesId"].append(massagesId)
        Groups.saveData(data)
        
    
    #TODO حذف گروه
    @staticmethod
    def Remove(Id:int):
        Groups.Remove(Id) #حذف همه پیام های گروه!
        data = Groups.loadData()
        del data[str(Id)]
        Groups.saveData(data)
        
    @staticmethod    
    def delAllMassages(Id:int):
        for i in Groups.findById(Id)["MassagesId"]:
            massage.Massages.Remove(i)
    
    #TODO ادیت گروه
    @staticmethod
    def Edit(Id, newgroup:Group):
        data = Groups.loadData()
        
        data[str(Id)] = {
            "Id":Id,
            "Title":newgroup.Title,
            "MembersId":newgroup.MembersId,
            "AdminId":newgroup.AdminId,
            "MassagesId":newgroup.MassagesId,
            "DefaultAgeRange":newgroup.DefaultAgeRange,
            "GroupTypeId":newgroup.GroupTypeId
        }
        
        
        Groups.saveData(data)
    
    

    
    
    #پیداکردن یک گروه با استفاده از آیدی
    @staticmethod
    def findById(Id):
        data = Groups.loadData()
        return data[str(Id)]
    

    @staticmethod
    def addUser(g_Id,u_Id):
        data = Groups.loadData()
        data[str(g_Id)]["MembersId"].remove(u_Id)
        Groups.saveData(data)
    
        
    # گرفتن دیتا از دیسک
    @staticmethod
    def loadData():
        data = {}
        with open("DAL/Jsons/Group.json", "r") as f:
            data = json.loads(f.read())
        f.close()    
        return data

    # سیو کردن دیتا در دیسک
    @staticmethod
    def saveData(data):
        with open("DAL/Jsons/Group.json", "w") as f:
            json.dump(data,f)
        f.close()    
          
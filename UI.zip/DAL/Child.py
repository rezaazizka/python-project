import json

class Child:
    
    def __init__(self,UserId,SchoolId,ParentsId):
        self.UserId = UserId
        self.SchoolId = SchoolId
        self.ParentsId = ParentsId
        
        



class Children:

    #TODO باید آیدی ها خود به خود اضافه شوند و دست کاربر نباشند
    #اضافه کردن بچه جدید
    #TODO: باید موقع اضافه شدن بچه به لیست بچه های والدین هم اضافه شود (یکی از والدین حتما موجود است)
    @staticmethod
    def Add(child:Child):
        with open("DAL/Jsons/Id/Child", "r") as f:
            Id = f.read()
        MId = int(Id) + 1
        child_data = {
            "Id":MId,
            "UserId":child.UserId,
            "SchoolId":child.SchoolId,
            "ParentsId":child.ParentsId,
        }
        
        with open("DAL/Jsons/Id/Child", "w") as f:
            f.write(str(MId))
        
        data = Children.loadData()
        data[MId] = child_data
        Children.saveData(data)
        
    #حذف کردن یک بچه
    #TODO: باید از لیست بچه های والدین
    @staticmethod
    def Remove(Id:int):
        data = Children.loadData()
        del data[str(Id)]
        Children.saveData(data)
        
    #پیدا کردن بچه با استفاده از آیدی
    @staticmethod
    def findById(Id):
        data = Children.loadData()
        return data[str(Id)]

    
    @staticmethod
    def isExist(userId):
        data = Children.loadData()
        for i in data:
            if userId == data[i]["UserId"]:
                return True
        return False
    
    #TODO این بخش برای پیداکردن آیدی بچه است که باید در آینده تکمیل شود
            
    
    #ادیت بچه
    #TODO: این بخش باید تکمیل شود
    @staticmethod
    def Edit(Id, newchild:Child):
        data = Children.loadData()
        
        data[str(Id)] = {
            "Id":Id,
            "UserId":newchild.UserId,
            "SchoolId":newchild.SchoolId,
            "ParentsId":newchild.ParentsId,
        }
        
        
        Children.saveData(data)

    #لود کردن دیتا در هارد
    @staticmethod
    def loadData():
        data = {}
        with open("DAL/Jsons/Child.json", "r") as f:
            data = json.loads(f.read())
        f.close()    
        return data

    #سیو کردن دیتا در هارد
    @staticmethod
    def saveData(data):
        with open("DAL/Jsons/Child.json", "w") as f:
            json.dump(data,f)
        f.close()    




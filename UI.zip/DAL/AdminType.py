import json
# تایپ های مختلف ادمین در اینجا هست
# مثلا تایپ روت توانایی اضافه کردن ادمین را دارد
# ادمین ها کار هایی مثل کنترل روی پیام ها و ... دارند که البته دسترسی به این که چه کسی پیام را نوشته ندارند 
class AdminType:
    
    def __init__(self,Type):
        self.Type = Type            #تایتل تایپ های مختلف که مثلا root , ...
        


#کنترل تایپ های ادمین
class AdminTypes:

    #TODO باید آیدی ها خود به خود اضافه شوند و دست کاربر نباشند
    # اضافه کردن تایپ جدید که یک تایپ می گیرد و اضافه می کند
    @staticmethod
    def Add(adminType:AdminType):
        with open("DAL/Jsons/Id/AdminType", "r") as f:
            Id = f.read()
        MId = int(Id) + 1
        adminType_data = {
            "Id":MId,
            "Type":adminType.Type,
        }
        
        with open("DAL/Jsons/Id/AdminType", "w") as f:
            f.write(str(MId))
        
        data = AdminTypes.loadData()
        data[MId] = adminType_data
        AdminTypes.saveData(data)
    
    # آیدی تایپ ادمین را می گیرد و آن را حذف
    # نباید تایپی حذف شود که توسط ادمینی مورد استفاده قرار می گیرد
    @staticmethod
    def Remove(Id:int):
        data = AdminTypes.loadData()
        del data[str(Id)]
        AdminTypes.saveData(data)
        
    # لیست تایپ های مختلف را بر می گرداند
    # خروجی به شکل لیستی از متن ها است
    # تایپ را با استفاده از آیدی پیدا می کند
    # خروجی به شکل دیکشنری دارای اطلاعات هارد می باشد
    @staticmethod
    def findById(Id):
        data = AdminTypes.loadData()
        return data[str(Id)]

    # آیدی تایپ را با استفاده از نام تایپ می یابد
    # ورودی نام تایپ است
    # خروجی به شکل عدد آیدی است
    @staticmethod
    def findIdBy(adminType):
        data = AdminTypes.loadData()
        for i in data:
            if data[i]["Type"] == adminType:
                return data[i]["Id"]
        raise Exception('adminType not exist')

    # ادیت تایپ
    #TODO باید در آینده تکمیل شود ... دو تایپ می گیرد و اولی را به دومی تبدیل و ذخیره می کند
    @staticmethod
    def Edit(Id, newadmintype:AdminType):
        data = AdminTypes.loadData()
        
        data[str(Id)] = {
            "Id":Id,
            "Type":newadmintype.Type,
        }
        
        
        AdminTypes.saveData(data)

    #لود کردن دیتا از هارد
    @staticmethod
    def loadData():
        data = {}
        with open("DAL/Jsons/AdminType.json", "r") as f:
            data = json.loads(f.read())
        f.close()    
        return data

    #سیو کردن دیتا در هارد   
    @staticmethod
    def saveData(data):
        with open("DAL/Jsons/AdminType.json", "w") as f:
            json.dump(data,f)
        f.close()    




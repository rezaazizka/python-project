import json

class User:
    
    def __init__(self,Name,UserName,Password,SexId,Age,GroupId = []):
        self.Name = Name
        self.UserName = UserName
        self.Password = Password
        self.SexId = SexId
        self.Age = Age
        self.GroupId = GroupId
        
        



class Users:

    #اضافه کردن یوزر جدید
    @staticmethod
    def Add(user:User):

        with open("DAL/Jsons/Id/User", "r") as f:
            Id = f.read()
        MId = int(Id) + 1

        user_data = {
            "Id":MId,
            "Name":user.Name,
            "UserName":user.UserName,
            "Password":user.Password,
            "SexId":user.SexId,
            "Age":user.Age,
            "GroupId":user.GroupId
        }
        
        with open("DAL/Jsons/Id/User", "w") as f:
            f.write(str(MId))
        
        data = Users.loadData()
        data[MId] = user_data
        Users.saveData(data)
        
        
        
        
        
    #حذف کردن یوزر
    @staticmethod
    def Remove(Id:int):
        data = Users.loadData()
        del data[str(Id)]
        Users.saveData(data)
        
    #پیدا کردن یوزر با آیدی
    @staticmethod
    def findById(Id):
        data = Users.loadData()
        return data[str(Id)]


    @staticmethod
    def addGroup(userId,groupId):
        data = Users.loadData()
        for i in data:
            if data[i]["Id"] == userId:
                data[i]["GroupId"].append(groupId)
        Users.saveData(data)
        
    #ادیت یوزر
    #TODO در آینده نوشته می شود
    @staticmethod
    def Edit(Id, newUser:User):
        data = Users.loadData()
        
        data[str(Id)] = {
            "Id":Id,
            "Name":newUser.Name,
            "UserName":newUser.UserName,
            "Password":newUser.Password,
            "SexId":newUser.SexId,
            "Age":newUser.Age,
            "GroupId":newUser.GroupId
        }
        
        
        Users.saveData(data)


    #لود کردن دیتا از دیسک``
    @staticmethod
    def loadData():
        data = {}
        # خواندن فایل جیسون یوزر و ریختن آن در دیکشنری دیتا
        with open("DAL/Jsons/User.json", "r") as f:
            data = json.loads(f.read())
        f.close()    
        return data
    #سیو کردن دیتا در هارد دیسک
    @staticmethod
    def saveData(data):
        with open("DAL/Jsons/User.json", "w") as f:
            json.dump(data,f)
        f.close()
            
            
   

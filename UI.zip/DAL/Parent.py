import json

class Parent:
    
    def __init__(self,UserId,JobId,ChildrenId):
        self.UserId = UserId
        self.JobId = JobId
        self.ChildrenId = ChildrenId
        



class Parents:

    #اضافه کردن والد (قبل از بچه ها والد اضافه می شود)
    #TODO اگر والد دوم هم اضافه شود باید والد اول این کار را بکند در این صورت باید از یک متد دیگر استفاده کرد که بچه ها به والد دوم اضافه بشوند.
    @staticmethod
    def Add(parent:Parent):
        with open("DAL/Jsons/Id/Parent", "r") as f:
            Id = f.read()
        MId = int(Id) + 1        
        parent_data = {
            "Id":MId,
            "UserId":parent.UserId,
            "JobId":parent.JobId,
            "ChildrenId":parent.ChildrenId,
        }
        
        with open("DAL/Jsons/Id/Parent", "w") as f:
            f.write(str(MId))
        
        data = Parents.loadData()
        data[MId] = parent_data
        Parents.saveData(data)
        
    #حذف کردن یک والد
    #TODO باید توجه کرد که اگر بچه ها بدون والد نمی شوند ایرادی ندارد وگرنه باید جلوی آن گرفته شود! جلوگیری در لایه BLL اتفاق می افتد.
    @staticmethod
    def Remove(Id:int):
        data = Parents.loadData()
        del data[str(Id)]
        Parents.saveData(data)
        
    #پیداکردن یک والد با استفاده از آیدی
    @staticmethod
    def findById(Id):
        data = Parents.loadData()
        return data[str(Id)]

    
    
    #ادیت یک والد
    #TODO در آینده نوشته شود
    def Edit(Id, newparent:Parent):
        data = Parents.loadData()
        
        data[str(Id)] = {
            "Id":Id,
            "UserId":newparent.UserId,
            "JobId":newparent.JobId,
            "ChildrenId":newparent.ChildrenId,
        }
        
        
        Parents.saveData(data)


    # گرفتن دیتا از دیسک
    @staticmethod
    def loadData():
        data = {}
        with open("DAL/Jsons/Parent.json", "r") as f:
            data = json.loads(f.read())
        f.close()    
        return data

    # سیو کردن دیتا در دیسک
    @staticmethod
    def saveData(data):
        with open("DAL/Jsons/Parent.json", "w") as f:
            json.dump(data,f)
        f.close()    




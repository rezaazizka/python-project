import json

class GroupType:
    
    def __init__(self,Type):

        self.Type = Type
        



class GroupTypes:

    #TODO باید آیدی ها خود به خود اضافه شوند و دست کاربر نباشند
    @staticmethod
    def Add(groupType:GroupType):
        
        with open("DAL/Jsons/Id/GroupType", "r") as f:
            Id = f.read()
        MId = int(Id) + 1
        
        groupType_data = {
            "Id":MId,
            "Type":groupType.Type,
        }
        
        with open("DAL/Jsons/Id/GroupType", "w") as f:
            f.write(str(MId))
        
        data = GroupTypes.loadData()
        data[MId] = groupType_data
        GroupTypes.saveData(data)
    
        
    @staticmethod
    def Remove(Id:int):
        data = GroupTypes.loadData()
        del data[str(Id)]
        GroupTypes.saveData(data)
        
        
    
        
        
    @staticmethod
    def findById(Id):
        data = GroupTypes.loadData()
        return data[str(Id)]

    @staticmethod
    def findIdBy(groupType):
        data = GroupTypes.loadData()
        for i in data:
            if data[i]["Type"] == groupType:
                return data[i]
        #TODO ارور نبود تایپ

    @staticmethod
    def Edit(Id, newgroupType:GroupType):
        data = GroupTypes.loadData()
        
        data[str(Id)] = {
        "Id":Id,
            "Type":newgroupType.Type,
        }

        
        GroupTypes.saveData(data)

    @staticmethod
    def loadData():
        data = {}
        with open("DAL/Jsons/GroupType.json", "r") as f:
            data = json.loads(f.read())
        f.close()    
        return data

    @staticmethod
    def saveData(data):
        with open("DAL/Jsons/GroupType.json", "w") as f:
            json.dump(data,f)
        f.close()    




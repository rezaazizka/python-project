import json
import BLL.Group as group


class Massage:
    
    #نکته مهم این است که پیام ها در صورت خالی بودن یک لیست خالی باشد نه none
    def __init__(self,Value,GroupId,UserId,Time,AgeRange = 0,SeenersId = []):
        self.Value = Value
        self.GroupId = GroupId
        self.UserId = UserId
        self.Time = Time
        self.AgeRange = AgeRange
        self.SeenersId = SeenersId
        
        
class Massages:
    
    #اضافه کردن گروه
    
    @staticmethod
    def Add(massage:Massage):
        with open("DAL/Jsons/Id/Massage", "r") as f:
            Id = f.read()
        MId = int(Id) + 1
        massage_data = {
            "Id":MId,
            "Value":massage.Value,
            "GroupId":massage.GroupId,
            "UserId":massage.UserId,
            "Time":massage.Time,
            "AgeRange":massage.AgeRange,
            "SeenersId":massage.SeenersId
        }
        
        with open("DAL/Jsons/Id/Massage", "w") as f:
            f.write(str(MId))
            
            
        data = Massages.loadData()
        data[MId] = massage_data
        Massages.saveData(data)
        #اضافه کردن پیام به گروه
        group.Groups.addMassagesId(massage.GroupId,MId)
    
    #TODO حذف گروه
    @staticmethod
    def Remove(Id:int):
        data = massages.loadData()
        del data[str(Id)]
        Massages.saveData(data)
    
    @staticmethod
    def Edit(Id, newmassage:Massage):
        data = massages.loadData()
        
        data[str(Id)] = {
            "Id":Id,
            "Value":newmassage.Value,
            "GroupId":newmassage.GroupId,
            "UserId":newmassage.UserId,
            "Time":newmassage.Time,
            "AgeRange":newmassage.AgeRange,
            "SeenersId":newmassage.SeenersId
        }
        
        
        Massages.saveData(data)
   
    
    
    
    
    #پیداکردن یک گروه با استفاده از آیدی
    @staticmethod
    def findById(Id):
        data = Massages.loadData()
        return data[str(Id)]
    
    
    

    # گرفتن دیتا از دیسک
    @staticmethod
    def loadData():
        data = {}
        with open("DAL/Jsons/Massages.json", "r") as f:
            data = json.loads(f.read())
        f.close()    
        return data

    # سیو کردن دیتا در دیسک
    @staticmethod
    def saveData(data):
        with open("DAL/Jsons/Massages.json", "w") as f:
            json.dump(data,f)
        f.close()   
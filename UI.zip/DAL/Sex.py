import json

class Sex:
    
    def __init__(self,Title):
        self.Title = Title
        



class Sexs:

    @staticmethod
    def Add(sex:Sex):
        with open("DAL/Jsons/Id/Sex", "r") as f:
            Id = f.read()
        MId = int(Id) + 1
        sex_data = {
            "Id":MId,
            "Title":sex.Title,
        }
        
        with open("DAL/Jsons/Id/Sex", "w") as f:
            f.write(str(MId))
        
        data = Sexs.loadData()
        data[MId] = sex_data
        Sexs.saveData(data)
    
        
    @staticmethod
    def Remove(Id:int):
        data = Sexs.loadData()
        del data[str(Id)]
        Sexs.saveData(data)
        

          
    @staticmethod
    def findById(Id):
        data = Sexs.loadData()
        return data[str(Id)]

    @staticmethod
    def findIdBy(SexTitle):
        data = Sexs.loadData()
        for i in data:
            if data[i]["Title"] == SexTitle:
                return data[i]
        #TODO ارور نبود تایپ


    @staticmethod
    def Edit(Id , newsex:Sex):

        data = Sexs.loadData()
    
        data[str(Id)] = {
            "Id":Id,
            "Title":newsex.Title,
        }
        
        
        Sexs.saveData(data)



    @staticmethod
    def loadData():
        data = {}
        with open("DAL/Jsons/Sex.json", "r") as f:
            data = json.loads(f.read())
        return data
        f.close()    

    @staticmethod
    def saveData(data):
        with open("DAL/Jsons/Sex.json", "w") as f:
            json.dump(data,f)
        f.close()    
            



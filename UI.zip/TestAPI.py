from fastapi import FastAPI
import BLL
import BLL.Child
import BLL.Group
import BLL.GroupType
import BLL.Job
import BLL.Massage
import BLL.Parent
import BLL.School
import BLL.Sex
import BLL.User
import BLL.Admin
import BLL.AdminType


app = FastAPI()


@app.get("/User/{item_id}")
async def user(item_id):
    code = str(item_id).split(";")

    for i in range(len(code)):
        if code[i] == "":
            code[i] = None


    if code[0] == "Login":
        try:
            return BLL.User.Users.Login(code[1],code[2])
        except Exception as e:
            return {"Error":str(e)}

    if code[0] == "Add":
        try:
            if code[6] == None:
                code[6] = []
            BLL.User.Users.Add(code[1],code[2],code[3],code[4],code[5],code[6])
            return "OK"
        except Exception as e:
            return {"Error":str(e)}

    if code[0] == "AllUserNames":
        try:
            return BLL.User.Users.AllUserNames()
        except Exception as e:
            return {"Error": str(e)}
    


    if code[0] == "Remove":
        try:
            BLL.User.Users.Remove(code[1])
            return "OK"
        
        except Exception as e:
            return {"Error": str(e)}
    
    if code[0] == "findById":
        try:
            return BLL.User.Users.findById(code[1])
        except Exception as e:
            return {"Error": str(e)}


    if code[0] == "findUserBy":
        try:
            return BLL.User.Users.findUserBy(code[1],code[2],code[3],code[4])
        except Exception as e:
            return {"Error": str(e)}
    
    if code[0] == "Edit":
        try:
            BLL.User.Users.Edit(code[1],code[2],code[3],code[4],code[5],code[6])
            return "OK"
        
        except Exception as e:
            return {"Error": str(e)}
        
    if code[0] == "joinGroup":
        try:
            BLL.User.Users.joinGroup(code[1],code[2])
            return "OK"
        except Exception as e:
            return {"Error": str(e)}
        
    if code[0] == "isChild":
        try:
            return BLL.User.Users.isChild(code[1])
        except Exception as e:
            return {"Error": str(e)}
    
    if code[0] == "isParent":
        try:
            return BLL.User.Users.isParent(code[1])
        except Exception as e:
            return {"Error": str(e)}

    if code[0] == "isExist":
        try:
            return BLL.User.Users.isExist(code[1])
        except Exception as e:
            return {"Error": str(e)}
        
    if code[0] == "findChildId":
        try:
            return BLL.User.Users.findChildId(code[1])
        except Exception as e:
            return {"Error": str(e)}

    if code[0] == "findSchoolById":
        try:
            return BLL.User.Users.findSchoolById(code[1])
        except Exception as e:
            return {"Error": str(e)}


    if code[0] == "findSchoolByUserName":
        try:
            return BLL.User.Users.findSchoolByUserName(code[1])
        except Exception as e:
            return {"Error": str(e)}

    
    if code[0] == "sex":
        try:
            return BLL.User.Users.sex(code[1],code[2])
        except Exception as e:
            return {"Error": str(e)}


    if code[0] == "findJobById":
        try:
            return BLL.User.Users.findJobById(code[1])
        except Exception as e:
            return {"Error": str(e)}
        

    if code[0] == "groupList":
        try:
            return BLL.User.Users.groupList(code[1])
        except Exception as e:
            return {"Error": str(e)}

    if code[0] == "getMassagesFromGroup":
        try:
            return BLL.User.Users.getMassagesFromGroup(code[1],code[2])
        except Exception as e:
            return {"Error": str(e)}


    return {"item_id": code}


@app.get("/Admin/{item_id}")
async def Admin(item_id):
    code = str(item_id).split(";")

    
    for i in range(len(code)):
        if code[i] == "":
            code[i] = None

    if code[0] == "Add":
        try:
            BLL.Admin.Admins.Add(code[1],code[2])
            return "OK"
        except Exception as e:
            return {"Error": str(e)}
        

    if code[0] == "Remove":
        try:
            BLL.Admin.Admins.Remove(code[1])
            return "Removed"
        except Exception as e:
            return {"Error": str(e)}
        


    if code[0] == "findById":
        try:
            return BLL.Admin.Admins.findById(code[1])
        except Exception as e:
            return {"Error": str(e)}
        

        
    if code[0] == "Edit":
        try:
            BLL.Admin.Admins.Edit(code[1],code[2])
            return "Edited"
        except Exception as e:
            return {"Error": str(e)}
        


    if code[0] == "isExist":
        try:
            return BLL.Admin.Admins.isExist(code[1])
        except Exception as e:
            return {"Error": str(e)}
        


@app.get("/AdminType/{item_id}")
async def AdminType(item_id):
    code = str(item_id).split(";")

    
    for i in range(len(code)):
        if code[i] == "":
            code[i] = None

    if code[0] == "Add":
        try:
            BLL.AdminType.AdminTypes.Add(code[1])
            return "Added"
        except Exception as e:
            return {"Error": str(e)}
        

    if code[0] == "Remove":
        try:
            BLL.AdminType.AdminTypes.Remove(code[1])
            return "Added"
        except Exception as e:
            return {"Error": str(e)}
        


    if code[0] == "adminTypeList":
        try:
            return BLL.AdminType.AdminTypes.adminTypeList()
            
        except Exception as e:
            return {"Error": str(e)}
        
    if code[0] == "allAdminTypes":
        try:
            return BLL.AdminType.AdminTypes.allAdminTypes()
        except Exception as e:
            return {"Error": str(e)}
    
        
    if code[0] == "Edit":
        try:
            BLL.AdminType.AdminTypes.Edit(code[1],code[2])
            return "Edited"
        except Exception as e:
            return {"Error": str(e)}
        
    if code[0] == "findById":
        try:
            return BLL.AdminType.AdminTypes.findById(code[1])
            
        except Exception as e:
            return {"Error": str(e)}
            


    if code[0] == "findIdBy":
        try:
            return BLL.AdminType.AdminTypes.findIdBy()
        except Exception as e:
            return {"Error": str(e)}
        


    if code[0] == "isExist":
        try:
            return BLL.AdminType.AdminTypes.isExist(code[1])
        except Exception as e:
            return {"Error": str(e)}
        


@app.get("/Child/{item_id}")
async def Child(item_id):
    code = str(item_id).split(";")


    for i in range(len(code)):
        if code[i] == "":
            code[i] = None
    


    if code[0] == "Add":
        try:
            BLL.Child.Children.Add(code[1],code[2],code[3])
            return "Added"
        except Exception as e:
            return {"Error":str(e)}
        

    if code[0] == "Remove":
        try:
            BLL.Child.Children.Remove(code[1])
            return "Removed"
        except Exception as e:
            return {"Error":str(e)}
        


    if code[0] == "findById":
        try:
            return BLL.Child.Children.findById(code[1])
        except Exception as e:
            return {"Error":str(e)}
        

        
    if code[0] == "Edit":
        try:
            BLL.Child.Children.Edit(code[1],code[2])
            return "Edited"
        except Exception as e:
            return {"Error":str(e)}
        


    if code[0] == "isExist":
        try:
            return BLL.Child.Children.isExist(code[1])
        except Exception as e:
            return {"Error":str(e)}


    if code[0] == "allChildren":
            try:
                return BLL.Child.Children.allChildren()
            except Exception as e:
                return {"Error":str(e)}



@app.get("/GroupType/{item_id}")
async def GroupType(item_id):
    code = str(item_id).split(";")


    for i in range(len(code)):
        if code[i] == "":
            code[i] = None
    

    if code[0] == "Add":
        try:
            BLL.GroupType.GroupTypes.Add(code[1])
            return "Added"
        except Exception as e:
            return {"Error": str(e)}
        

    if code[0] == "Remove":
        try:
            BLL.GroupType.GroupTypes.Remove(code[1])
            return "Removed"
        except Exception as e:
            return {"Error": str(e)}
        


    if code[0] == "findById":
        try:
            return BLL.GroupType.GroupTypes.findById(code[1])
        except Exception as e:
            return {"Error": str(e)}
        
    if code[0] == "findIdBy":
        try:
            return BLL.GroupType.GroupTypes.findIdBy(code[1])
        except Exception as e:
            return {"Error": str(e)}
    
    if code[0] == "allGroupTypes":
        try:
            return BLL.GroupType.GroupTypes.allGroupTypes()
        except Exception as e:
            return {"Error": str(e)}
    
        
    if code[0] == "Edit":
        try:
            BLL.GroupType.GroupTypes.Edit(code[1],code[2])
            return "Edited"
        except Exception as e:
            return {"Error": str(e)}
    
    if code[0] == "isExist":
        try:
            return BLL.GroupType.GroupTypes.isExist(code[1])
        except Exception as e:
            return {"Error": str(e)}
        


        
@app.get("/parent/{item_id}")
async def parent(item_id):
    code = str(item_id).split(";")

    for i in range(len(code)):
        if code[i] == "":
            code[i] = None

    if code[0] == "Add":
        try:
            BLL.Parent.Parents.Add(code[1],code[2])
            return "Added"
        except Exception as e:
            return {"Error": str(e)}
        

    if code[0] == "Remove":
        try:
            BLL.Parent.Parents.Remove(code[1])
            return "Removed"
        except Exception as e:
            return {"Error": str(e)}
        


    if code[0] == "findById":
        try:
            return BLL.Parent.Parents.findById(code[1])
        except Exception as e:
            return {"Error": str(e)}
        
    if code[0] == "findParent":
        try:
            return BLL.Parent.Parents.findParent(code[1])
        except Exception as e:
            return {"Error": str(e)}

    if code[0] == "Edit":
        try:
            BLL.Parent.Parents.Edit(code[1],code[2])
            return "Edited"
        except Exception as e:
            return {"Error": str(e)}
        


    if code[0] == "isExist":
        try:
            return BLL.Parent.Parents.isExist(code[1])
        except Exception as e:
            return {"Error": str(e)}
        
    if code[0] == "AlluserId":
        try:
            return BLL.Parent.Parents.AlluserId()
        except Exception as e:
            return {"Error": str(e)}
    




@app.get("/Group/{item_id}")
async def Group(item_id):
    code = str(item_id).split(";")


    for i in range(len(code)):
        if code[i] == "":
            code[i] = None
    
    if code[0] == "Add":
        try:
            if code[5] == None:
                code[5] = 0
            if code[6] == None:
                code[6] = []

            BLL.Group.Groups.Add(code[1],code[2],code[3],code[4],code[5],code[6])
            return "Added"
        except Exception as e:
            return {"Error": str(e)}
        
    if code[0] == "addMassagesId":
        try:
            BLL.Group.Groups.addMassagesId(code[1],code[2])
            return "OK"
        except Exception as e:
            return {"Error": str(e)}
    
    if code[0] == "delAllMassages":
        try:
            BLL.Group.Groups.delAllMassages(code[1])
            return "OK"

        except Exception as e:
            return {"Error": str(e)}
    
    if code[0] == "allGroups":
        try:
            return BLL.Group.Groups.allGroups()
        except Exception as e:
            return {"Error": str(e)}
    

    if code[0] == "findById":
        try:
            return BLL.Group.Groups.findById(code[1])
        except Exception as e:
            return {"Error": str(e)}
    

    if code[0] == "addUser":
        try:
            BLL.Group.Groups.addUser(code[1],code[2])
            return "OK"
        except Exception as e:
            return {"Error": str(e)}
    

    if code[0] == "isExist":
        try:
            return BLL.Group.Groups.isExist(code[1])
        except Exception as e:
            return {"Error": str(e)}


@app.get("/Job/{item_id}")
async def Job(item_id):
    code = str(item_id).split(";")


    for i in range(len(code)):
        if code[i] == "":
            code[i] = None
    
    if code[0] == "Add":
        try:
            return BLL.Job.Jobs.Add(code[1])
        except Exception as e:
            return {"Error": str(e)}
        
    if code[0] == "jobsList":
        try:
            return BLL.Job.Jobs.jobsList()
        except Exception as e:
            return {"Error": str(e)}
        

    if code[0] == "alljobs":
        try:
            return BLL.Job.Jobs.alljobs()
        except Exception as e:
            return {"Error": str(e)}
        

    if code[0] == "findById":
        try:
            return BLL.Job.Jobs.findById(code[1])
        except Exception as e:
            return {"Error": str(e)}
        


    if code[0] == "findIdBy":
        try:
            return BLL.Job.Jobs.findIdBy(code[1])
        except Exception as e:
            return {"Error": str(e)}
        

    if code[0] == "Edit":
        try:
            return BLL.Job.Jobs.Edit(code[1],code[2])
        except Exception as e:
            return {"Error": str(e)}
    
    if code[0] == "isExist":
        try:
            return BLL.Job.Jobs.isExist(code[1])
        except Exception as e:
            return {"Error": str(e)}
        


@app.get("/Massage/{item_id}")
async def Massage(item_id):
    code = str(item_id).split(";")


    for i in range(len(code)):
        if code[i] == "":
            code[i] = None

    if code[0] == "Add":
        try:
            if code[5] == None:
                code[5] = 0
            if code[6] == None:
                code[6] = []
            BLL.Massage.Massages.Add(code[1],code[2],code[3],code[4],code[5],code[6])
            return "Added"
        except Exception as e:
            return {"Error": str(e)}
        

    if code[0] == "Remove":
        try:
            BLL.Massage.Massages.Remove(code[1])
            return "Ok"
        except Exception as e:
            return {"Error": str(e)}
        


    # if code[0] == "Edit":
    #     try:
    #         return BLL.Massage.Massages.Edit(code[1],code[2])
    #     except Exception as e:
    #         return {"Error": str(e)}
        



    if code[0] == "findById":
        try:
            return BLL.Massage.Massages.findById(code[1])
        except Exception as e:
            return {"Error": str(e)}
        




    if code[0] == "isExist":
        try:
            return BLL.Massage.Massages.isExist(code[1])
        except Exception as e:
            return {"Error": str(e)}
        


@app.get("/School/{item_id}")
async def School(item_id):
    code = str(item_id).split(";")


    for i in range(len(code)):
        if code[i] == "":
            code[i] = None

    if code[0] == "Add":
        try:
            BLL.School.Schools.Add(code[1],code[2])
            return "OK"
        except Exception as e:
            return {"Error": str(e)}
        
    if code[0] == "Remove":
        try:
            BLL.School.Schools.Remove(code[1])
            return "OK"
        except Exception as e:
            return {"Error": str(e)}
        

    if code[0] == "schoolsNameList":
        try:
            return BLL.School.Schools.schoolsNameList()
        except Exception as e:
            return {"Error": str(e)}


    if code[0] == "allSchools":
        try:
            return BLL.School.Schools.allSchools()
        except Exception as e:
            return {"Error": str(e)}


    if code[0] == "findById":
        try:
            return BLL.School.Schools.findById(code[1])
        except Exception as e:
            return {"Error": str(e)}


    if code[0] == "Edit":
        try:
            BLL.School.Schools.Edit(code[1],code[2],code[3])
            return "OK"
        except Exception as e:
            return {"Error": str(e)}
        

    if code[0] == "schoolsNameList":
        try:
            return BLL.School.Schools.schoolsNameList()
        except Exception as e:
            return {"Error": str(e)}
        
    if code[0] == "isExist":
        try:
            return BLL.School.Schools.isExist(code[1])
        except Exception as e:
            return {"Error": str(e)}
        
    if code[0] == "allSchools":
        try:
            return BLL.School.Schools.allSchools()
        except Exception as e:
            return {"Error": str(e)}
        
    if code[0] == "allStudents":
        try:
            return BLL.School.Schools.allStudents(code[1])
        except Exception as e:
            return {"Error": str(e)}
        
@app.get("/Sex/{item_id}")
async def Sex(item_id):
    code = str(item_id).split(";")


    for i in range(len(code)):
        if code[i] == "":
            code[i] = None

    if code[0] == "Add":
        try:
            BLL.Sex.Sexs.Add(code[1])
            return "OK"
        except Exception as e:
            return {"Error": str(e)}
        
    if code[0] == "Remove":
        try:
            BLL.Sex.Sexs.Remove(code[1])
            return "OK"
        except Exception as e:
            return {"Error": str(e)}

    if code[0] == "sexTitleList":
        try:
            return BLL.Sex.Sexs.sexTitleList()
        except Exception as e:
            return {"Error": str(e)}

    if code[0] == "allSexs":
        try:
            return BLL.Sex.Sexs.allSexs()
        except Exception as e:
            return {"Error": str(e)}

    if code[0] == "findById":
        try:
            return BLL.Sex.Sexs.findById(code[1])
        except Exception as e:
            return {"Error": str(e)}

    if code[0] == "Edit":
        try:
            return BLL.Sex.Sexs.Edit(code[1],code[2])
        except Exception as e:
            return {"Error": str(e)}

    if code[0] == "isExist":
        try:
            return BLL.Sex.Sexs.isExist(code[1])
        except Exception as e:
            return {"Error": str(e)}
        #750
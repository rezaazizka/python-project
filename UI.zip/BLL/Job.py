import DAL.Job as Dal
class Jobs:

    @staticmethod
    def Add(Title):
        Dal.Jobs.Add(Dal.Job(Title))
        

        
    @staticmethod
    def Remove(Id):
        if Jobs.isExist(Id):
            Dal.Jobs.Remove(Id)        
        else:
            raise Exception('Id dose not exist')
    @staticmethod
    def jobsList():
        data = Dal.Jobs.loadData()
        result = []
        for i in data:
            result.append(data[i]["Title"])
        return result
        
        
   
    @staticmethod
    def alljobs():
        data = Dal.Jobs.loadData()
        result = []
        for i in data:
            result.append(data[i])
        return result      
        
        
    @staticmethod
    def findById(Id):
        data = Jobs.loadData()
        return data[str(Id)]

    @staticmethod
    def findIdBy(jobTitle):
        Dal.Jobs.findIdBy(jobTitle)

    @staticmethod
    def Edit(Id,newjob):
        if Jobs.isExist(Id):
            Dal.Jobs.Edit(Id,newjob)
        else:
            raise Exception("Id dose not exist")
    @staticmethod
    def isExist(Id):
        data = Dal.Jobs.loadData()
        for i in data:
            if Id == data[i]["Id"]:
                return True
        return False
        

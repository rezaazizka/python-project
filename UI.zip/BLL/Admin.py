import DAL.Admin as Dal


#ادمین ها را با این کلاس مدیریت می کنیم
class Admins:

    
    @staticmethod
    def Add(UserId, AdminTypeId):
        if not Admins.isExist(UserId):
            Dal.Admins.Add(Dal.Admin(UserId,AdminTypeId))
        else:
            raise Exception('UserId taken')
        


        
        
        
        
    # حذف کردن ادمین (حتما یک ادمین روت وجود داشته باشد)
    # آیدی ادمین را می گیرد و آن را حذف
    @staticmethod
    def Remove(Id:int):
        if Admins.isExist(Id):
            Dal.Admins.Remove(Id)
        else:
            raise Exception("Id not exist")
        
    #پیدا کردن ادمین با استفاده از آیدی آن        
    @staticmethod
    def findById(Id):
        if not Admins.isExist(Id):
            raise Exception("Id dose not exist")
        else:
            return Dal.Admins.findById(Id)

    # ادیت ادمین
    #TODO باید در آینده تکمیل شود ... دو ادمین می گیرد و اولی را به دومی تبدیل و ذخیره می کند
    @staticmethod
    def Edit(Id,newadmin):
        if Admins.isExist(Id):
            Dal.Admins.Edit(Id,newadmin)
        else:
            raise Exception ("Id dose not exist")
    @staticmethod
    def isExist(UserId):
        data=Dal.Admins.loadData()
        for i in data:
            if data[i]["UserId"]==UserId:
                return True
        return False


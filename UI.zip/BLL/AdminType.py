import DAL.AdminType as Dal
# تایپ های مختلف ادمین در اینجا هست
# مثلا تایپ روت توانایی اضافه کردن ادمین را دارد
# ادمین ها کار هایی مثل کنترل روی پیام ها و ... دارند که البته دسترسی به این که چه کسی پیام را نوشته ندارند 


#کنترل تایپ های ادمین
class AdminTypes:

    #TODO باید آیدی ها خود به خود اضافه شوند و دست کاربر نباشند
    # اضافه کردن تایپ جدید که یک تایپ می گیرد و اضافه می کند
    @staticmethod
    def Add(Type):
        Dal.Admintypes.Add(Dal.AdminType(Type))
    # آیدی تایپ ادمین را می گیرد و آن را حذف
    # نباید تایپی حذف شود که توسط ادمینی مورد استفاده قرار می گیرد
    @staticmethod
    def Remove(Id:int):
        if AdminTypes.isExist(Id):
            Dal.AdminTypes.Remove(Id)
        else:
            raise Exception('Id dose not exist')
        
        
    # لیست تایپ های مختلف را بر می گرداند
    # خروجی به شکل لیستی از متن ها است
    @staticmethod
    def adminTypeList():
        data =Dal.AdminTypes.loadData()
        result = []
        for i in data:
            result.append(data[i]["Type"])
        return result
    
    # همه تایپ ها را بر می گرداند
    # خروجی به صورت دیکشنری می باشد که اطلاعات تایپ را دارد
    @staticmethod
    def allAdminTypes():
        data = Dal.AdminTypes.loadData()
        result = []
        for i in data:
            result.append(data[i])
        return result      
    
    
    # تایپ را با استفاده از آیدی پیدا می کند
    # خروجی به شکل دیکشنری دارای اطلاعات هارد می باشد
    @staticmethod
    def findById(Id):
        if AdminTypes.isExist(Id):
            Dal.AdminType.findById(Id)
        else:
            raise Exception('Id dose not exist')
        
    # آیدی تایپ را با استفاده از نام تایپ می یابد
    # ورودی نام تایپ است
    # خروجی به شکل عدد آیدی است
    @staticmethod
    def findIdBy(adminType):
        Dal.AdminTypes.findIdBy(adminType)
        
        
    # ادیت تایپ
    #TODO باید در آینده تکمیل شود ... دو تایپ می گیرد و اولی را به دومی تبدیل و ذخیره می کند
    @staticmethod
    def Edit(Id , newadmintype ):
        if AdminTypes.isExist(Id):
            Dal.AdminTypes.Edit(Id,newadmintype)
        else:
            raise Exception('Id dose not exist')


    @staticmethod
    def isExist(Id):
        data=Dal.AdminTypes.loadData()
        for i in data:
            if data[i]["Id"]==Id:
                return True
        return False
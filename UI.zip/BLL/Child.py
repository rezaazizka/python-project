import BLL.Parent
import BLL.School
import BLL.User
import DAL.Child as Dal
import BLL
class Children:

    #اضافه کردن بچه جدید
    #TODO: باید موقع اضافه شدن بچه به لیست بچه های والدین هم اضافه شود (یکی از والدین حتما موجود است)
    @staticmethod
    def Add(UserId,SchoolId,ParentsId):
        # if Children.isExist(UserId):
            # raise Exception('Id is taken')
        # else:
        if BLL.User.Users.isExist(UserId) and BLL.School.Schools.isExist(SchoolId) and BLL.Parent.Parents.isExist(ParentsId):
            Dal.Children.Add(Dal.Child(UserId,SchoolId,ParentsId))
            
    #حذف کردن یک بچه
    #TODO: باید از لیست بچه های والدین
    @staticmethod
    def Remove(Id:int):
        if Children.isExist(Id):
            Dal.Children.Remove(Id)
        else:
            raise Exception('Id not exist')



            
    #TODO پیدا کردن بچه با استفاده از آیدی
    @staticmethod
    def findById(Id):
        if Children.isExist(int(Id)):
            return Dal.Children.findById(int(Id))
        else:
            raise Exception('Id not exist')
    

    @staticmethod
    def isExist(Id):
        data=Dal.Children.loadData()
        for i in data:
            if data[i]["Id"]==Id:
                return True
        return False
    
    @staticmethod
    def isUExist(userId):
        data=Dal.Children.loadData()
        for i in data:
            if data[i]["UserId"]==userId:
                return True
        return False
        #TODO یوزر آیدی  باید در آینده تکمیل شود
    @staticmethod
    def findChildBy(SchoolId=None,UserId=None,ParentsId=None):
        data = Dal.Children.loadData()
        if SchoolId != None:
            for i in data:
                if data[i]["SchoolId"] == SchoolId:
                    return data[i]
            
        elif UserId != None:
            for i in data:
                if data[i]["UserId"] == UserId:
                    return data[i]
        elif ParentsId!=None:
            for i in data:
                if data[i]["ParentsId"] == ParentsId:
                    return data[i]
    
        
        
    @staticmethod
    def allChildren():
        data = Dal.Children.loadData()
        result = []
        for i in data:
            result.append(data[i])
        return result
        
    #ادیت بچه
    #TODO: این بخش باید تکمیل شود
    @staticmethod
    def Edit(Id, newchild):
        if Children.isExist(Id):
            Dal.Children.Edit(Id, newchild)
        else:
            raise Exception(' id dose not exist')

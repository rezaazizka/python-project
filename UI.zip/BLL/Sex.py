import DAL.Sex as Dal
class Sexs:

    @staticmethod
    def Add(Title):
        f = 0
        if Title in Sexs.sexTitleList():
            f = 1
            raise Exception("This sex is exist")
        
        if f == 0:
            Dal.Sexs.Add(Dal.Sex(Title))
        
    
        
    @staticmethod
    def Remove(Id:int):
        if Sexs.isExist(Id):
            Dal.Sexs.Remove(Id)
        else:
            raise Exception("User with this id dose not exist")

        
    @staticmethod
    def sexTitleList():
        data = Dal.Sexs.loadData()
        result = []
        for i in data:
            result.append(data[i]["Title"])
        return result
    
    @staticmethod
    def allSexs() -> list:
        data = Dal.Sexs.loadData()
        result = []
        for i in data:
            result.append(data[i])
        return result
    
      
    @staticmethod
    def findById(Id):
        if Id.isdigit():
            return Dal.Sexs.findById(Id)
        raise Exception("Id is not int")

    @staticmethod
    def findIdBy(SexTitle):
        f=0
        data = Dal.Sexs.loadData()
        for i in data:
            if data[i]["SexTitle"] == SexTitle:
                return data[i]["Id"]
                f=1
        if f==0:
            raise Exception("user not exist")


    @staticmethod
    def Edit(Id, Title):
        f = 0
        if not Id.isdigit():
            f = 1
            raise Exception("Id is not int")
        if not Sexs.isExist(Id):
            f = 1
            raise Exception("Id is not exist")
        
        if Title in Sexs.sexTitleList():
            f = 1
            raise Exception("This sex is exist")
        
        if f == 0:
            Dal.Sexs.Edit(Id,Dal.Sex(Title))
        
    @staticmethod
    def isExist(Id:int):
        if Id.isdigit():
            idlist = []
            for i in Sexs.allSexs():
                idlist.append(i["Id"])
            if Id in idlist:
                return True
        return False
            
        
    
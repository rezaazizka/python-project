import DAL.GroupType as Dal

class GroupTypes:

    @staticmethod
    def Add(Type):
        Dal.GroupTypes.Add(Type)
                
    @staticmethod
    def allGroupTypes():
        data = GroupTypes.loadData()
        result = []
        for i in data:
            result.append(data[i])
        return result      
    @staticmethod
    def groupTypeList():
        data = Dal.GroupTypes.loadData()
        result = []
        for i in data:
            result.append(data[i]["Type"])
        return result
        
        
    @staticmethod
    def Remove(Id:int):
        if GroupTypes.isExist(Id):
            Dal.GroupTypes.Remove(Id)
        
        
        

    @staticmethod
    def findById(Id):
        if GroupTypes.isExist(Id):
            Dal.GroupTypes.findById(Id)
        else:
            raise Exception('Id not exist')
        
        
    @staticmethod
    def findIdBy(groupType):

        Dal.GroupTypes.findIdBy(groupType)


        
    @staticmethod
    def Edit(Id, newgroupType):
        if GroupTypes.isExist(Id):
            Dal.GroupTypes.Edit(Id, newgroupType)
        else:
            raise Exception('Id not exist')
        
    
    @staticmethod
    def isExist(Id):
        data=Dal.GroupTypes.loadData()
        for i in data:
            if data[i]["Id"]==Id:
                return True
        return False
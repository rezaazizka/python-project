import DAL.User as Dal
import BLL.Sex as sex
import BLL.Group as group
import BLL.Child as child
import BLL.School as school
import BLL.Job as job
import BLL.Parent as parent
import BLL.Massage as massage
class Users:
   #اضافه کردن یوزر جدید
    @staticmethod
    def Add(Name,UserName,Password,SexId,Age,GroupId = []):
        
        # چک کردن درست بودن نام (کمتر از ۳ تا حرف نباشد - عدد نباشد)
        f=0
        if len(Name)<3:
            raise Exception("name must have at least 3 letters")
            f=1
        
        for i in Name:
            if i.isdigit():
                raise Exception("cant use number in name")
                f=1
        
        #  چک کردن این که یوزر نیم درست باشد (فاصله نداشته باشد - انگلیسی باشد)
        for i in UserName:
            if "a"<=i<="z"or "A"<=i<="Z" or i=="@" or i=='_':
                pass
            else:
                raise Exception('only letters (a to Z) and _ are allowed') 
                f=1

            if UserName in Users.AllUserNames():
                raise Exception('this username is taken')
                f=1

        # چک کردن این که پسورد درست باشد (کمتر از ۴ کراکتر نباشد)   
        if len(Password)<4:
            raise Exception("must be more than 4 numbers")
            f=1
        
        # چک کردن این که sexId درست باشد (موجود باشد و عدد باشد)
        for i in Password:
            if i.isdigit():
                pass
            else:
                raise Exception("you can only use numbers")
                f=1
        
        
        idList = []
        
        if str(SexId).isdigit():
            for i in sex.Sexs.allSexs():
                idList.append(i["Id"])
            if int(SexId) in idList:
                pass
            else:
                raise Exception('Wrong sexId')
                f=1
            
        if not str(Age).isdigit():
            f = 1
            raise Exception("Age is not number!")
        
        # چک کردن این که اگر گروهی وارد شد درست باشد (پرنت حق ورود به گروه بچه ها را ندارند و گروه موجود باید وارد شود)
        idList = []
        for i in group.Groups.allGroups():
            idList.append(i["Id"])
        for i in GroupId:
            if i in idList:
                pass
            else:
                raise Exception('Wrong GroupId')
                f=1

                
        if f==0:
            Dal.Users.Add(Dal.User(Name,UserName,Password,SexId,Age,GroupId))




    @staticmethod
    def AllUserNames():
        data = Dal.Users.loadData()
        result=[]
        for i in data:
            result.append(data[i]["UserName"])
        return result




    @staticmethod
    def Remove(Id:int):
        if Users.isExist(Id):
            Dal.Users.Remove(Id)
        else:
            raise Exception("User with this id dose not exist")

                
    #TODO پیدا کردن یوزر با آیدی
    @staticmethod
    def findById(Id:int):
        if Users.isExist(Id):
            return Dal.Users.findById(Id)
        else:
            raise Exception("User with this id dose not exist")


        
        
    #TODO این بخش برای پیداکردن آیدی یوزر است که باید در آینده تکمیل شود
    @staticmethod
    def findUserBy(Name=None,UserName=None,SexId=None,GroupId=None):
        data = Dal.Users.loadData()
        if Name!=None:
            f=0
            result=[]
            for i in data:
                if  Name in data[i]["Name"]:
                    result.append(data[i])
                    return result
                    f=1
            if f==0:
                raise Exception("user not exist")
            
        elif UserName != None:
            f=0
            # result=[]
            for i in data:
                if data[i]["UserName"] == UserName:
                    return data[i]
                    f=1
            if f==0:
                raise Exception("user not exist")
            
        elif SexId != None:
            f=0
            result=[]
            for i in data:
                if data[i]["SexId"] == int(SexId):
                    result.append(data[i])
                    f = 1
            if f==0:
                raise Exception("user not exist")
            return result
            
        elif GroupId != None:
            f=0
            result=[]
            for i in data:
                if data[i]["GroupId"] == GroupId:
                    result.append(data[i])
                    return result
                    f=1
            if f==0:
                raise Exception("user not exist")
         

    #ادیت یوزر
    #TODO در آینده نوشته می شود
    @staticmethod
    def Edit(Id,Name=None,UserName=None,Password=None,Age=None,SexId=None):
        f=0
        
        if Users.isExist(Id):
            oldUser = Users.findById(Id)
        else:
            f = 1
            raise Exception("This user is not exist")

        if f == 0:
            if Name == None or Name == oldUser["Name"]:
                Name = oldUser["Name"]
            else:
                if len(Name)<3:
                    raise Exception("name must have at least 3 letters")
                    f=1
                
                for i in Name:
                    if i.isdigit():
                        raise Exception("cant use number in name")
                        f=1

            if UserName == None or UserName == oldUser["UserName"]:
                UserName = oldUser["UserName"]
            else:                
                for i in UserName:
                    if "a"<=i<="z"or "A"<=i<="Z" or i=="@" or i=='_':
                        pass
                    else:
                        raise Exception('only letters (a to Z) and _ are allowed') 
                        f=1
                    if UserName in Users.AllUserNames() :
                        raise Exception('this username is taken')
                        f=1

            if Password == None or Password == oldUser["Password"]:
                Password = oldUser["Password"]
            else:
                if len(Password)<4:
                    raise Exception("must be more than 4 numbers")
                    f=1
            
                # چک کردن این که sexId درست باشد (موجود باشد و عدد باشد)
                for i in Password:
                    if i.isdigit():
                        pass
                    else:
                        raise Exception("you can only use numbers")
                        f=1
            
            
            if SexId == None or SexId == oldUser["SexId"]:
                SexId = oldUser["SexId"]
            else:
                idList = []
                
                for i in sex.Sexs.allSexs():
                    idList.append(i["Id"])
                if SexId in idList:
                    pass
                else:
                    f=1
                    raise Exception('Wrong sexId')
            
            if Age == None or Age == oldUser["Age"]:
                Age = oldUser["Age"]
            else:
                if not Age.isdigit():
                    f = 1
                    raise Exception("Age is not number!")
        
        
            GroupId = oldUser["GroupId"]

        if f == 0:
            Dal.Users.Edit(Id,Dal.User(Name,UserName,Password,SexId,Age,GroupId))

    
    def joinGroup(userId,groupId):
        f = 0
        if not Users.isExist(userId):
            f = 1
            raise Exception("User is not exist")
        if not group.Groups.isExist(groupId):
            f = 1
            raise Exception("Group is not exist")
        
        if f == 0:
            Dal.Users.addGroup(userId,groupId)
            group.Groups.addUser(groupId,userId)

    def leftGroup(userId,groupId):
        ...
        # Users.findById(userId)["GroupId"].remove(groupId)
        # group.Groups.findById(groupId)[]    
    
    #TODO لاگین
    @staticmethod
    def Login(Username,Password):
        
        user = Users.findUserBy(UserName=Username)
        if user == None:
            raise Exception("User name is not exist!") #TODO در آینده از ارور ها استفاده می کنیم!
        
        elif user["Password"] == Password:
            return [True, user]
        
        else:
            raise Exception("Your password is not true!") #TODO در آینده از ارور ها استفاده می کنیم
    
    
    @staticmethod
    def isChild(Id):
        if Users.isExist(int(Id)):
            return child.Children.isExist(int(Id))
    
    #TODO تکمیل این مورد
    def isParent(Id):
        if Users.isExist(int(Id)):
            return parent.Parents.isUExist(int(Id))
    
    #TODO تکمیل این مورد
    def isExist(Id):
        data = Dal.Users.loadData()
        result=[]
        for i in data:
            result.append(data[i]["Id"])
        if int(Id) in result:
            return True
        else:
            return False
            raise Exception('User with this id dose not exist')

    
    
    #--------------------------------------------------------------------------
    
    def findChildId(Id):
        return child.Children.findChildBy(UserId=Id)

    def findSchoolById(Id):
        if Users.isChild(Id):
            return school.Schools.findById(Users.findChildId(Id)["SchoolId"])
        raise Exception("User is not child")
    
    def findSchoolByUserName(Username):
        return school.Schools.findById(Users.findChildId(Users.findUserBy(UserName=Username)["Id"])["SchoolId"])

    #---------------------------------------------------------------------------
    
    def sex(Id = None, Username = None):
        if Id != None:
            return sex.Sexs.findById(Users.findById(Id)["SexId"])
        
    def findJobById(Id):
        if Users.isParent(Id):
            return job.Jobs.findById(parent.Parents.findParentBy(userId=Id)["JobId"])
        
        
    #----------------------------------------------------------------------------
    
    def groupList(Id):
        result = []
        for i in Users.findById(Id)["GroupId"]:
            result.append(group.Groups.findById(i))
        return result
    
    def getMassagesFromGroup(Id,groupId):
        user = Users.findById(Id)
        if (groupId in user["GroupId"]):
            result = []
            for i in group.Groups.findById(groupId)["MassagesId"]:
                imassage = massage.Massages.findById(i)
                if imassage["AgeRange"] <= user["Age"]:
                    result.append(imassage)
            return result
                

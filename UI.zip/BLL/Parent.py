import DAL.Parent as Dal

class Parents:

    #اضافه کردن والد (قبل از بچه ها والد اضافه می شود)
    #TODO اگر والد دوم هم اضافه شود باید والد اول این کار را بکند در این صورت باید از یک متد دیگر استفاده کرد که بچه ها به والد دوم اضافه بشوند.
    @staticmethod
    def Add(UserId,JobId,ChildrenId):
        if UserId in Parents.AlluserId():
            raise Exception('UserId is taken')
        else:
            Dal.Parents.Add(Dal.parent(UserId,JobId,ChildrenId))
             
    #حذف کردن یک والد
    #TODO باید توجه کرد که اگر بچه ها بدون والد نمی شوند ایرادی ندارد وگرنه باید جلوی آن گرفته شود! جلوگیری در لایه BLL اتفاق می افتد.
    @staticmethod
    def Remove(Id:int):

        if Parents.isExist(Id):
            Dal.Parents.Remove(Id)
        else:
            raise Exception('user dose not exist')
        
       
      
    #پیداکردن یک والد با استفاده از آیدی
    @staticmethod
    def findById(Id):
        if Parents.isExist(int(Id)):
            return Dal.Parents.findById(int(Id))
        else:
            raise Exception('user dose not exist')


    @staticmethod
    def AlluserId():

        data = Dal.Parents.loadData()
        list=[]
        for i in data:
            list.append(data[i]['UserId'])
        return list
    @staticmethod
    def findParent(userId):
        
        data = Dal.Parents.loadData()
        for i in data:
            if int(userId) == int(data[i]["UserId"]):
                return data[i]
        raise Exception("Parent Not Exist")
    
    @staticmethod
    def isExist(Id):
        data = Dal.Parents.loadData()
        for i in data:
            if int(Id) == int(data[i]["Id"]):
                return True
        return False
        

    @staticmethod
    def isUExist(userId):
        data = Dal.Parents.loadData()
        for i in data:
            if int(userId) == int(data[i]["UserId"]):
                return True
        return False
    #ادیت یک والد
    #TODO در آینده نوشته شود
    @staticmethod
    def Edit(Id,newparent:Dal.Parent):
        if Parents.isExist(Id):
            Dal.Parents.Edit(Id,newparent)
        else:
            raise Exception('userdose not exist')
        
       

            



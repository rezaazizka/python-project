import BLL.Group
import BLL.User
import DAL.Massage as Dal
import BLL

class Massages:
    
    #اضافه کردن پیام
    
    @staticmethod
    def Add(Value,GroupId,UserId,Time,AgeRange = 0,SeenersId = []):
        if BLL.Group.Groups.isExist(GroupId) and BLL.User.Users.isExist(UserId):
            Dal.Massages.Add(Dal.Massage(Value,GroupId,UserId,Time,AgeRange,SeenersId))



    @staticmethod
    def Remove(Id):
        if Massages.isExist(Id):
            Dal.Massages.Remove(Id)
        else:
            raise Exception('Id not exist')
    @staticmethod
    def Edit(Id, newmassage):
        if Massages.isExist(Id):
            Dal.Massages.Edit(Id, newmassage)
        else:
            raise Exception('Id not exist')
    
    
    #پیداکردن یک گروه با استفاده از آیدی
    @staticmethod
    def findById(Id):
        if Massages.isExist(Id):
            Dal.Massage.findById(Id)
        else:
            raise Exception('user dose not exist')

    
    @staticmethod
    def isExist(Id):
        data= Dal.Massages.loadData()
        for i in data:
            if Id==data[i]['Id']:
                return True
        return False
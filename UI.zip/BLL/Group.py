import DAL.Group as Dal
        
class Groups:
    
    #اضافه کردن گروه
    
    @staticmethod
    def Add(Title,MembersId,AdminId,GroupTypeId,DefaultAgeRange = 0,MassagesId = []):
        Dal.Groups.Add(Title,MembersId,AdminId,GroupTypeId,DefaultAgeRange = 0,MassagesId = [])
               
    
    #اضافه کردن پیام به گروه
    @staticmethod
    def addMassagesId(groupId,massagesId):
        Dal.Groups.addMassageId(groupId,massagesId)
        
    @staticmethod
    def delAllMassages(Id:int):  
        Dal.Groups.delAllMassages(Id)

    @staticmethod
    def allGroups():
        data = Dal.Groups.loadData()
        result = []
        for i in data:
            result.append(data[i])
        return result
    #پیداکردن یک گروه با استفاده از آیدی
    @staticmethod
    def findById(Id):
        if Groups.isExist(Id):
            Dal.Groups.findById(Id)
        else:
            raise Exception("Id dose not exist")

    @staticmethod
    def addUser(groupId,userId):
        Dal.Groups.addUser(groupId,userId)

    @staticmethod
    def isExist(Id):
        data=Dal.Groups.loadData()
        for i in data:
            if data[i]["Id"]==Id:
                return True
        return False
import DAL.Schools as Dal
import BLL.Child as child

class Schools:

    #اضافه کردن مدرسه
    @staticmethod
    def Add(Name,Location):
        
        f=0
        if len(Name)<3:
            raise Exception("name must have at least 3 letters")
            f=1
        
        for i in Name:
            if i.isdigit():
                raise Exception("cant use number in name")
                f=1

        if len(Location)<3:
            raise Exception("Location must have at least 3 letters")
            f=1
        
        if f == 0:
            Dal.Schools.Add(Dal.School(Name,Location))
                
    #حذف کردن یک مدرسه
    @staticmethod
    def Remove(Id:int):
        f = 0
        if not Schools.isExist(Id):
            f = 1
            raise Exception("User with this id dose not exist")

        if len(Schools.allStudents(Id)) != 0:
            f = 1
            raise Exception("This school has students!")
        
        if f == 0:
            Dal.Remove(Id)

    #لیست تمام مدارس    
    @staticmethod
    def schoolsNameList():
        result = []
        for i in Schools.allSchools():
            result.append(i["Name"])
        return result
        
    #دیتای تمام مدارس
    @staticmethod
    def allSchools() -> list:
        data = Dal.Schools.loadData()
        result = []
        for  i in data:
            result.append(data[i])
        return result
    
    #پیداکردن یک مدرسه با استفاده از آیدی
    @staticmethod
    def findById(Id):
        if Id.isdigit():
            return Dal.Schools.findById(Id)
        raise Exception("Id is not int")


    #ادیت یک مدرسه
    #TODO در آینده نوشته شود
    @staticmethod
    def Edit(Id,Name,Location):
        f = 0
        
        if Schools.isExist(Id):
            f = 1
            raise Exception("Id is not exist")
        
        if len(Name)<3:
            raise Exception("name must have at least 3 letters")
            f=1
        
        for i in Name:
            if i.isdigit():
                raise Exception("cant use number in name")
                f=1

        if len(Location)<3:
            raise Exception("Location must have at least 3 letters")
            f=1

        if f == 0:
            Dal.Schools.Edit(Id,Dal.School(Name,Location))


    @staticmethod
    def isExist(Id:int):
        if Id.isdigit():
            idlist = []
            for i in Schools.allSchools():
                idlist.append(i["Id"])
            if Id in idlist:
                return True
        return False
            
    def allStudents(Id:int):
        if Schools.isExist(Id):
            data = child.Children.allChildren()
            result = []
            for i in data:
                if data["SchoolId"] == Id:
                    result.append(i)